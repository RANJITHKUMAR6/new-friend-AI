// functions/index.js
//
// BetterFriend — Cloud Function chat proxy
// ------------------------------------------------------------------
// Verifies the caller's Firebase Auth token, calls Claude with a
// warm-companion system prompt, saves the exchange to Firestore, and
// returns { mood, reply } to the app.
//
// Setup:
//   cd functions
//   npm install firebase-functions firebase-admin node-fetch@2
//   firebase functions:secrets:set ANTHROPIC_API_KEY
//   firebase deploy --only functions:chat

const { onRequest } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");
const fetch = require("node-fetch");

admin.initializeApp();
const db = admin.firestore();

const ANTHROPIC_API_KEY = defineSecret("ANTHROPIC_API_KEY");

const SYSTEM_PROMPT = `You are the mascot in BetterFriend, a calm, night-themed companion app. You are the user's warm, non-judgmental well-wisher. The user shares daily "pros" (good things) and "cons" (hard things) with you.

Voice: calm, gentle, present-tense, like a close friend who is genuinely glad to hear from them. Use plain, warm language. No therapy-speak, no numbered lists, no emojis unless it truly fits.

Rules:
- 1 to 3 sentences maximum. Short replies land better at night.
- Reflect back what they actually said in your own words before adding insight — don't generic-template it.
- If they share something hard, validate first; never rush to fix or minimize it.
- If they share something good, help them notice why it mattered.
- Occasionally (not every time) end with one short, easy, optional question to keep them sharing — never interrogate.
- Never diagnose, never give medical/clinical advice, never claim to be human.

Output format (strict): start your reply with exactly one mood tag in square brackets, one of [warm] [soft] [calm], then a space, then your reply. Nothing else before or after — no preamble, no labels, no quotes.
Example: [soft] That sounds like a heavy thing to carry today. You don't have to have it figured out tonight.`;

function parseMoodReply(raw, fallbackText) {
  const match = raw.match(/^\[(warm|soft|calm)\]\s*([\s\S]*)$/i);
  if (match) {
    return { mood: match[1].toLowerCase(), reply: match[2].trim() || fallbackText };
  }
  return { mood: "calm", reply: raw || fallbackText };
}

exports.chat = onRequest(
  { secrets: [ANTHROPIC_API_KEY], cors: true },
  async (req, res) => {
    if (req.method !== "POST") {
      return res.status(405).json({ error: "Method not allowed" });
    }

    // ---- 1. Verify Firebase Auth ID token ----
    const authHeader = req.headers.authorization || "";
    const idToken = authHeader.startsWith("Bearer ") ? authHeader.split(" ")[1] : null;

    if (!idToken) {
      return res.status(401).json({ error: "Missing Authorization Bearer token" });
    }

    let decodedToken;
    try {
      decodedToken = await admin.auth().verifyIdToken(idToken);
    } catch (err) {
      console.error("Invalid ID token:", err);
      return res.status(401).json({ error: "Invalid or expired token" });
    }
    const uid = decodedToken.uid;

    // ---- 2. Validate request body ----
    const { message, history } = req.body || {};
    if (!message || typeof message !== "string") {
      return res.status(400).json({ error: "Request body must include a 'message' string" });
    }
    const safeHistory = Array.isArray(history) ? history.slice(-12) : [];

    // ---- 3. Call Claude ----
    let mood = "calm";
    let reply = "Thanks for sharing that with me.";
    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": ANTHROPIC_API_KEY.value(),
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 200,
          system: SYSTEM_PROMPT,
          messages: [...safeHistory, { role: "user", content: message }],
        }),
      });

      const data = await response.json();
      const raw = (data.content || [])
        .filter((b) => b.type === "text")
        .map((b) => b.text)
        .join("")
        .trim();

      const parsed = parseMoodReply(raw, reply);
      mood = parsed.mood;
      reply = parsed.reply;
    } catch (err) {
      console.error("Anthropic API call failed:", err);
      // Fall through and still save + return the gentle default reply above,
      // so the app never hits a dead end even if the AI call fails.
    }

    // ---- 4. Save the reflection to Firestore ----
    try {
      await db
        .collection("users")
        .doc(uid)
        .collection("reflections")
        .add({
          message,
          reply,
          mood,
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
        });
    } catch (err) {
      // Don't fail the whole request just because logging failed —
      // the user should still get their reply.
      console.error("Failed to save reflection to Firestore:", err);
    }

    // ---- 5. Respond ----
    return res.status(200).json({ mood, reply });
  }
);
